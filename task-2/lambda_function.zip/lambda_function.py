import boto3

client = boto3.client('sns')

def lambda_handler(event,context):
    print(str(event))
    instance_id = event['detail']['instance-id']
    instance_state= event['detail']['state']
    message="Hello Team, Instance with id={} has {}".format(instance_id,instance_state)
    
    response = client.subscribe(
    TopicArn='arn:aws:sns:us-east-1:418805593611:Ec2-Updates',
    Protocol='email',
    Endpoint='mangalekaromkar.aws@gmail.com',
    ReturnSubscriptionArn= False
)
    client.publish(TopicArn ="arn:aws:sns:us-east-1:418805593611:Ec2-Updates",
                    Message= message)